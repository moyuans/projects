# myTeam.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from captureAgents import CaptureAgent
import random, time, util
from game import Directions, Actions
import game

from math import sqrt, log

#################
# Team creation #
#################

def createTeam(firstIndex, secondIndex, isRed,
			   first = 'PacmanAgent', second = 'GhostAgent'):
  """
  This function should return a list of two agents that will form the
  team, initialized using firstIndex and secondIndex as their agent
  index numbers.  isRed is True if the red team is being created, and
  will be False if the blue team is being created.

  As a potentially helpful development aid, this function can take
  additional string-valued keyword arguments ("first" and "second" are
  such arguments in the case of this function), which will come from
  the --redOpts and --blueOpts command-line arguments to capture.py.
  For the nightly contest, however, your team will be created without
  any extra arguments, so you should make sure that the default
  behavior is what you want for the nightly contest.
  """

  # The following line is an example only; feel free to change it.

  return [eval(first)(firstIndex), eval(second)(secondIndex)]


#############
#method#
#############

def getClosestFoodPoint(agent, gameState):
  capsules = agent.getCapsules(gameState)
  foodList = agent.getFood(gameState).asList(True)
  if capsules != None:
	for i in range(len(capsules)):
	  foodList.append(capsules[i])

  minDistance = 999999
  closestP = None
  for foodPosition in foodList:
	newD = agent.getMazeDistance(gameState.getAgentPosition(agent.index), foodPosition)	 # captureAgent.getMazeDistance(pos1, pos2)
	if newD < minDistance:
	  minDistance = newD
	  closestP = foodPosition

  return closestP

  
# not wall for pacman to return to its own side
def getClosestBoundaryPoint(agent, gameState):

  layout = gameState.data.layout
  heightB = layout.height
  widthB = layout.width / 2
  minD1 = 999999
  closestBP = None

  for i in range(heightB):
	if agent.red == True:
	  if not layout.walls[widthB - 1][i] and agent.getMazeDistance(gameState.getAgentPosition(agent.index),
																   (widthB - 1, i)) < minD1:
		minD1 = agent.getMazeDistance(gameState.getAgentPosition(agent.index), (widthB - 1, i))
		closestBP = (widthB - 1, i)

	if agent.red == False:
	  if not layout.walls[widthB + 1][i] and agent.getMazeDistance(gameState.getAgentPosition(agent.index),
																   (widthB + 1, i)) < minD1:
		minD1 = agent.getMazeDistance(gameState.getAgentPosition(agent.index), (widthB + 1, i))
		closestBP = (widthB + 1, i)


  return closestBP


# not wall for pacman to return to its own side
def getUpClosestBoundaryPoint(agent, gameState):

  layout = gameState.data.layout
  heightB = layout.height/2
  widthB = layout.width / 2
  minD1 = 999999
  closestBP = None

  for i in range(heightB-3):
	if agent.red == True:
	  if not layout.walls[widthB - 1][i] and agent.getMazeDistance(gameState.getAgentPosition(agent.index),
																   (widthB - 1, i)) < minD1:
		minD1 = agent.getMazeDistance(gameState.getAgentPosition(agent.index), (widthB - 1, i))
		closestBP = (widthB - 1, i)

	if agent.red == False:
	  if not layout.walls[widthB + 1][i] and agent.getMazeDistance(gameState.getAgentPosition(agent.index),
																   (widthB + 1, i)) < minD1:
		minD1 = agent.getMazeDistance(gameState.getAgentPosition(agent.index), (widthB + 1, i))
		closestBP = (widthB + 1, i)


  return closestBP

def getDownClosestBoundaryPoint(agent, gameState):

  layout = gameState.data.layout
  heightB = layout.height
  widthB = layout.width / 2
  minD1 = 999999
  closestBP = None

  for i in range(heightB/2+3,heightB):
	if agent.red == True:
	  if not layout.walls[widthB - 1][i] and agent.getMazeDistance(gameState.getAgentPosition(agent.index),
																   (widthB - 1, i)) < minD1:
		minD1 = agent.getMazeDistance(gameState.getAgentPosition(agent.index), (widthB - 1, i))
		closestBP = (widthB - 1, i)

	if agent.red == False:
	  if not layout.walls[widthB + 1][i] and agent.getMazeDistance(gameState.getAgentPosition(agent.index),
																   (widthB + 1, i)) < minD1:
		minD1 = agent.getMazeDistance(gameState.getAgentPosition(agent.index), (widthB + 1, i))
		closestBP = (widthB + 1, i)


  return closestBP  
  
#self food closest to boundary#
def getPossibleFoodProtecting(agent, gameState):

  foodList = agent.getFoodYouAreDefending(gameState).asList(True)
  minDistance = 999999
  possibleFood = None

  layout = gameState.data.layout
  heightB = layout.height
  widthB = layout.width / 2
  entryList = []
  for i in range(heightB):
	if not layout.walls[widthB][i]:
	  entryList.append((widthB, i))

  for foodPosition in foodList:
	for entry in entryList:
	  newD = agent.getMazeDistance(entry, foodPosition)	 # captureAgent.getMazeDistance(pos1, pos2)
	  if newD < minDistance:
		minDistance = newD
		possibleFood = foodPosition

  return possibleFood

# closest food to opponent pacman
def getPossibleFoodPwO(agent, enemyPos, foodListP):
  minDistance = 999999
  possibleFood = None

  for food in foodListP:
	if agent.getMazeDistance(enemyPos, food) < minDistance:
	  possibleFood = food
	  minDistance = agent.getMazeDistance(enemyPos, food) < minDistance

  return possibleFood



def getAcSuccessors(layout, position):
  successors = []
  for action in [Directions.NORTH, Directions.SOUTH, Directions.EAST, Directions.WEST]:
	x, y = position
	dx, dy = Actions.directionToVector(action)
	nextx, nexty = int(x + dx), int(y + dy)
	if not layout.walls[nextx][nexty]:
	  nextState = (nextx, nexty)
	  successors.append((nextState, action))

  return successors

def getLegalActions(layout, position):
  successors = []
  for action in [Directions.NORTH, Directions.SOUTH, Directions.EAST, Directions.WEST]:
	x, y = position
	dx, dy = Actions.directionToVector(action)
	nextx, nexty = int(x + dx), int(y + dy)
	if not layout.walls[nextx][nexty]:
	  successors.append(action)

  return successors


def breadthFirstSearch(layout, position, closestP):
  forward = util.Queue()
  expand = set()
  path = []
  fatherNode = {}

  start = position

  forward.push((start, 'Start', 0))
  expand.add(start)
  while not forward.isEmpty():

	node = forward.pop()
	if node[0] == closestP:
	  path.append(node[1])
	  while fatherNode[node][0] != start:
		path.append(fatherNode[node][1])
		node = fatherNode[node]
	  path.reverse()
	  return path

	for new_node in getAcSuccessors(layout, node[0]):
	  if new_node[0] not in expand:
		expand.add(new_node[0])
		fatherNode[new_node] = node
		forward.push(new_node)



################
# TREE NODE#
################

class treeNode:

  def __init__(self, actionL=None, parent=None, gameState=None, agentIndex = 1, opponentPos = None):  # gameSate or something else like position

	self.agentIndex = agentIndex
	self.action = actionL
	self.parent = parent
	self.children = []
	self.visits = 1
	self.wins = 0
	self.unexploredAction = gameState.getLegalActions(self.agentIndex)
	self.gameState = gameState
	self.opponentPos = opponentPos
	self.opponentRecord = opponentRecord(self.opponentPos, self.gameState.data.layout)
	self.actionPair = {} #check combination of self and opponent move

  def ucb1(self):
	s = sorted(self.children, key=lambda c: c.wins / c.visits + sqrt(2 * log(self.visits) / c.visits))[-1]

	return s

  def addNode(self, action, successor):

	visit = self.opponentRecord.unexploredAction
	actionO = None
	for i in range(len(visit)):
	  actionT = visit[i]
	  if (action, actionT) not in self.actionPair.keys():
		actionO = actionT

	nextOR = self.opponentRecord.successorPos(actionO)

	child = treeNode(actionL=action, parent=self, gameState=successor, agentIndex=self.agentIndex, opponentPos = nextOR.pos)
	self.children.append(child)

	self.actionPair[(child.action, actionO)] = 1
	count = 0
	for key in self.actionPair.keys():
	  if key[0] == action:
		count = count +1

	if count == len(self.opponentRecord.unexploredAction):
	  self.unexploredAction.remove(action)

	return child

  def assignNode(self, action, successor):
	actionO = random.choice(self.opponentRecord.unexploredAction)
	nextOR = self.opponentRecord.successorPosD(actionO)

	child = treeNode(actionL=action, parent=self, gameState=successor, agentIndex= self.agentIndex, opponentPos = nextOR.pos)
	self.children.append(child)

	return child

  def isEnd(self):
	return self.gameState.isOver()

  def eatOpponent(self):
	if self.gameState.getAgentPosition(self.agentIndex) == self.opponentRecord.pos:
	  return True

  def escapeOpponent(self):
	if self.gameState.getAgentPosition(self.agentIndex) != self.opponentRecord.pos:
	  return True

class opponentRecord:

  def __init__(self, selfpos = None, layout = None):
	self.pos = selfpos
	self.layout = layout
	self.unexploredAction = getLegalActions(self.layout, self.pos) # if not all legal actions, follow baseline team action choice

  def remove(self, action):
	return self.unexploredAction.remove(action)

  def successorPos(self, action):
	#self.unexploredAction.remove(action)
	x,y = self.pos
	vector = Actions.directionToVector(action)
	x1, y1 = vector
	pos = (x+x1, y+y1)
	nextOR = opponentRecord(pos, self.layout)

	return nextOR

  def successorPosD(self, action):
	x,y = self.pos
	vector = Actions.directionToVector(action)
	x1, y1 = vector
	pos = (x+x1, y+y1)
	nextOR = opponentRecord(pos, self.layout)

	return nextOR


####################################################
# UCT SEARCH WITH DIFFERENT VALUE CONSIDERATION #
####################################################

def uct(rootState, iteration, agentIndex, opponentPos):
  rootNode = treeNode(gameState=rootState, agentIndex=agentIndex, opponentPos = opponentPos)
  for i in range(iteration):
	descedent = treePolicy(rootNode)
	value = defaultPolicy(descedent)
	backPropagation(descedent, value)
  return rootNode.ucb1().action

def uctE(rootState, iteration, agentIndex, opponentPos):
  rootNode = treeNode(gameState=rootState, agentIndex=agentIndex, opponentPos = opponentPos)
  for i in range(iteration):
	descedent = treePolicy(rootNode)
	value = defaultPolicyE(descedent)
	backPropagation(descedent, value)

  return rootNode.ucb1().action


def treePolicy(node):
  while not node.isEnd():
	if node.unexploredAction != []:
	  return expand(node)
	else:
	  node = node.ucb1()  # for choosing descedent

  return node

def expand(node):
  action = random.choice(node.unexploredAction)
  successor = node.gameState.generateSuccessor(node.agentIndex, action)
  child = node.addNode(action, successor)
  return child


def defaultPolicy(node):
  steps = 8
  start = 0
  while not node.eatOpponent() and start != steps:
	start = start + 1
	#if start < steps:
	action = random.choice(node.unexploredAction)
	successor = node.gameState.generateSuccessor(node.agentIndex, action)
	node = node.assignNode(action, successor)

  return steps - start	# evaluate final state.reward...score?

# for not meet ghost
def defaultPolicyE(node):
  limit = 8
  start = 0
  while start < limit and node.escapeOpponent():
	start = start + 1
	action = random.choice(node.unexploredAction)
	successor = node.gameState.generateSuccessor(node.agentIndex, action)
	node = node.assignNode(action, successor)

  return start


def backPropagation(node, value, r = 0.5):
  # backpropagation methods
  while node:
	node.visits += 1
	node.wins += value
	value = r * value
	node = node.parent


	
def MaxAction(self, gameState, food):

	#bfs get the path to the nearest food
	self.bfsActions = []
	layout = gameState.data.layout
	widthS = layout.width / 2
	position = gameState.getAgentPosition(self.index)
	self.bfsActions = breadthFirstSearch(layout, position, food)
	
	# check if there are op could be seen
	op_distance = 9999
	op_index = 9999
	for i in self.getOpponents(gameState):
		if self.getCurrentObservation().getAgentPosition(i)!= None:
			opDistance = self.getMazeDistance(gameState.getAgentPosition(self.index), self.getCurrentObservation().getAgentPosition(i))
			x,y = self.getCurrentObservation().getAgentPosition(i)
			if opDistance < op_distance and x>=widthS and self.red==True:
				op_distance = opDistance
				op_index = i
			if opDistance < op_distance and x<widthS and self.red==False:
				op_distance = opDistance
				op_index = i
	
	if op_index!=9999 and gameState.getAgentState(op_index).scaredTimer !=0:
		return self.bfsActions[0]
	"""
	actions = gameState.getLegalActions(self.index)
	successor = gameState.generateSuccessor(self.index, action)
	"""
	if op_distance < 8 :
		actions = gameState.getLegalActions(self.index)
		for action in actions:
			if len(actions)!=1 and trap(self,gameState,action):
				actions.remove(action)
		if len(actions)!=1 and (Directions.STOP in actions):
			actions.remove(Directions.STOP)
		op_position = self.getCurrentObservation().getAgentPosition(op_index)
		self.op_bfsActions = breadthFirstSearch(layout, position, op_position)
		if len(actions) !=1 and (self.op_bfsActions[0] in actions):
			actions.remove(self.op_bfsActions[0])
		return random.choice(actions)
	else :
		return self.bfsActions[0]
	
	
def trap(self,gameState,action):
	successor = gameState.generateSuccessor(self.index, action)
	sucActions = successor.getLegalActions(self.index)

	for i in range(1,3):
			if len(sucActions) == 2:
				return True
			#find legal action
			new_food = getClosestFoodPoint(self, successor)
			layout = successor.data.layout
			self.newbfsActions = breadthFirstSearch(layout, successor.getAgentPosition(self.index), new_food)
			new_action = self.newbfsActions[0]
		
			successor = successor.generateSuccessor(self.index, new_action)
			sucActions = successor.getLegalActions(self.index)
	
	return False
	
##########
# Agents #
##########

class PacmanAgent(CaptureAgent):

  def registerInitialState(self, gameState):
	"""
	This method handles the initial setup of the
	agent to populate useful fields (such as what team
	we're on).

	A distanceCalculator instance caches the maze distances
	between each pair of positions, so your agents can use:
	self.distancer.getDistance(p1, p2)

	IMPORTANT: This method may run for at most 15 seconds.
	"""

	'''
	Make sure you do not delete the following line. If you would like to
	use Manhattan distances instead of maze distances in order to save
	on initialization time, please take a look at
	CaptureAgent.registerInitialState in captureAgents.py.
	'''
	CaptureAgent.registerInitialState(self, gameState)
	self.bfsActions = []
	self.totalFoodToEat = 0


	#gameState is the initial state?

	'''
	Your initialization code goes here, if you need any.
	'''

  def getSuccessor(self, gameState, action):
	from util import nearestPoint
	"""
	Finds the next successor which is a grid position (location tuple).
	"""
	successor = gameState.generateSuccessor(self.index, action)
	pos = successor.getAgentState(self.index).getPosition()
	if pos != nearestPoint(pos):
	  # Only half a grid position was covered
	  return successor.generateSuccessor(self.index, action)
	else:
	  return successor



  def chooseAction(self, gameState):
	
	actions = gameState.getLegalActions(self.index)

	'''
	You should change this in your own agent.
	if agent.isGhost then chooseAction1()
	else if
	agent.hasfood >= n chooseAction2()
	else if
	agent.hasfood < n chooseAction3()
	'''

	x, y = gameState.getAgentPosition(self.index)
	layout = gameState.data.layout
	#if gameState.is

	widthS = layout.width / 2

	self.totalFoodToEat = len(self.getFoodYouAreDefending(gameState).asList())


	if gameState.getAgentPosition(self.index) == gameState.getInitialAgentPosition(self.index) and len(self.bfsActions) != 0:
	  self.bfsActions = []
	
		
	foodLeft = len(self.getFood(gameState).asList())
	
	
	if foodLeft <= 2 or (self.getScore(gameState) == 0 and gameState.getAgentState(self.index).numCarrying==1):
		clBP = getClosestBoundaryPoint(self,gameState)
		position = gameState.getAgentPosition(self.index)
		self.bfsActions = breadthFirstSearch(layout, position, clBP)
		return self.bfsActions[0]
	
	if self.getScore(gameState) == 0 :
		clBP = getClosestFoodPoint(self, gameState)
		position = gameState.getAgentPosition(self.index)
		self.bfsActions = breadthFirstSearch(layout, position, clBP)
		return self.bfsActions[0]
	
	
	if self.red == True:
	  if x < widthS-1 :
		clBP = getClosestFoodPoint(self, gameState)
		position = gameState.getAgentPosition(self.index)
		self.bfsActions = breadthFirstSearch(layout, position, clBP)
		return self.bfsActions[0]
	  
	  
	  if x >= widthS-1 :
		if gameState.getAgentState(self.index).numCarrying < 5:
		  clBP = getClosestFoodPoint(self, gameState)
		if gameState.getAgentState(self.index).numCarrying >= 5:
		  clBP = getClosestBoundaryPoint(self, gameState)  ###MODIFIED TO RANDOM POINTS NOT CLOSE TO BOUNDARY
		return MaxAction(self, gameState, clBP)


	if self.red == False:
	  if x >= widthS+1:
		clBP = getClosestFoodPoint(self, gameState)
		position = gameState.getAgentPosition(self.index)
		self.bfsActions = breadthFirstSearch(layout, position, clBP)
		return self.bfsActions[0]
		
	  if x < widthS+1:
		if gameState.getAgentState(self.index).numCarrying < 5:
		  clBP = getClosestFoodPoint(self, gameState)
		if gameState.getAgentState(self.index).numCarrying >= 5:
		  clBP = getClosestBoundaryPoint(self, gameState)  
		return MaxAction(self, gameState, clBP)




class GhostAgent(CaptureAgent):

  def registerInitialState(self, gameState):

	CaptureAgent.registerInitialState(self, gameState)
	self.bfsActions = []


  def chooseAction(self, gameState):

	actions = gameState.getLegalActions(self.index)
	layout = gameState.data.layout
	foodList = self.getFoodYouAreDefending(gameState).asList(True)


	#get opponent pacman index or none
	observability = False
	enemyIndex = None
	enemyPos = None
	for i in self.getOpponents(gameState):
	  if self.getCurrentObservation().getAgentPosition(i) != None and self.getCurrentObservation().getAgentState(i).isPacman:
		observability = True
		enemyIndex = i
		enemyPos = self.getCurrentObservation().getAgentState(i).configuration.pos


	if observability == True and self.getMazeDistance(gameState.getAgentPosition(self.index), enemyPos) > 5:
	  foodPro = getPossibleFoodPwO(self, enemyPos, foodList)
	  if gameState.getAgentPosition(self.index) == foodPro:
		return random.choice(actions)
		#return Directions.STOP
	  else:
		self.bfsActions = breadthFirstSearch(layout, gameState.getAgentPosition(self.index), foodPro)
		actionT = self.bfsActions[0]
		self.bfsActions = []
		return actionT


	if observability == True and self.getMazeDistance(gameState.getAgentPosition(self.index), enemyPos) <= 5:
	  if self.getMazeDistance(gameState.getAgentPosition(self.index), enemyPos) == 1:
		return breadthFirstSearch(layout, gameState.getAgentPosition(self.index), enemyPos)[0]
	  else:
		return uct(gameState, 650, self.index, enemyPos)



	if observability == False:
	  foodP = getPossibleFoodProtecting(self, gameState)
	  if gameState.getAgentPosition(self.index) == foodP:
		return random.choice(actions)
		#return Directions.STOP

	  else:
		self.bfsActions = breadthFirstSearch(layout, gameState.getAgentPosition(self.index), foodP)
		actionT = self.bfsActions[0]
		self.bfsActions = []
		return actionT

	else:
	  return random.choice(actions)

